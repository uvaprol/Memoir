API_KEY = '6228897236:AAHQtrWqaIZjTtRJykbYQK87Ukv2VCYTc6w'
REG_SRC = 'http://127.0.0.1/enterance'
ADMINS_ID = [1814998712]
ADMINS_COMMAND = ['/shutdown', '/drop_base']
API_PASSWORD = 'Ну очень сложный'